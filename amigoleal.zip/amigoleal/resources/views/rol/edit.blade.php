<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=in, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="{{url('/rol/'.$rol->id )}}" method="post">
    @csrf
    {{method_field('PATCH')}}    
    
    @include('rol.form');

    </form>
    
</body>
</html>
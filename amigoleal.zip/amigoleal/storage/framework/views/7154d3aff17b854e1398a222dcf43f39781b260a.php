<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=in, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(url('/rol/'.$rol->id )); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo e(method_field('PATCH')); ?>    
    
    <?php echo $__env->make('rol.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    </form>
    
</body>
</html><?php /**PATH C:\xampp\htdocs\proyectoslaravel\amigoleal\resources\views/rol/edit.blade.php ENDPATH**/ ?>
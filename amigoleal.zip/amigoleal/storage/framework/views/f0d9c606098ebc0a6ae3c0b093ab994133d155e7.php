<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<a href="<?php echo e(url('rol/create')); ?>"> Nuevo Rol </a>
    
<table class="table table-ligth">

    <thead class="thead-ligth">
        <tr>
            <th>#</th>
            <th>Tipo Rol</th>
        </tr>
    </thead>

    <tbody>
        <?php $__currentLoopData = $rols; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rol->id); ?></td>
            <td><?php echo e($rol->Tipo_Rol); ?></td>
            <td>
            
            <a href="<?php echo e(url('/rol/'.$rol->id.'/edit')); ?>">
                Editar
            </a>
            </td>

            <td>
            
            <form action="<?php echo e(url('/rol/'.$rol->id)); ?> " method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('DELETE')); ?>

            <input type="submit" onclick="return confirm('¿Quiere borrar?')" value="Borrar">
            </form>
            </td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>

</body>
</html><?php /**PATH C:\xampp\htdocs\proyectoslaravel\amigoleal\resources\views/rol/index.blade.php ENDPATH**/ ?>